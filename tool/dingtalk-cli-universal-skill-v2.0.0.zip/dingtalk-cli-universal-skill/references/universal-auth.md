# 通用授权方案（Platform-Agnostic Auth）

> 本文档从原 WorkBuddy 平台特有授权方案提取，经过通用化处理，适用于任意 AI Agent 平台。

## 授权架构总览

```
┌─────────────────────────────────────────────────────┐
│                    用户 (User)                       │
│  在浏览器/钉钉 App 中完成 OAuth 和 PAT 确认          │
└─────────────┬──────────────────┬─────────────────────┘
              │                  │
     OAuth 登录         PAT Scope 授权
     (Step A/B)         (Step C/E)
              │                  │
              ▼                  ▼
┌─────────────────────────────────────────────────────┐
│                 dws CLI (本地)                       │
│  存储 token → 发起请求 → 携带凭证调用钉钉服务端       │
└─────────────┬───────────────────────────────────────┘
              │ HTTPS (带 Authorization)
              ▼
┌─────────────────────────────────────────────────────┐
│              钉钉开放平台 (Server)                    │
│  验证 token → 检查 scope → 返回结果/拒绝            │
└─────────────────────────────────────────────────────┘
```

## 三层权限模型详解

### 第1层：OAuth 登录（Identity）

**解决问题**："当前用户是谁？"

| 项目 | 说明 |
|---|---|
| 触发条件 | 首次使用、token 过期、用户主动要求登录 |
| 命令 | `dws auth login` 或 `dws auth login --device` |
| 有效期 | 通常数天到数周（取决于钉钉侧策略） |
| 存储位置 | 系统 Keychain / 凭据管理器 |
| 失效信号 | `not_authenticated`、`AUTH_TOKEN_EXPIRED`、`USER_TOKEN_ILLEGAL` |

**两种登录方式对比：**

| | 浏览器跳转 (A方案) | 设备流 (B方案) |
|---|---|---|
| 适用场景 | 有桌面/浏览器的环境 | 无桌面/远程/容器环境 |
| 用户体验 | 自动打开浏览器 | 手动打开链接+输入授权码 |
| 命令 | `dws auth login` | `dws auth login --device` |
| 推荐度 | ✅ 首选 | ⚠️ 兜底 |

### 第2层：组织 CLI 访问权限（Org Access）

**解决问题**："企业/组织是否允许通过 CLI 访问数据？"

| 项目 | 说明 |
|---|---|
| 配置位置 | 钉钉开放平台 → 组织管理 → CLI 访问权限 |
| 操作者 | **组织管理员**（非普通用户） |
| 一次配置 | 配置后该组织下所有成员均可使用 CLI |
| 缺失信号 | `ORG_CLI_ACCESS_DENIED` 或类似组织级错误 |

**如果用户遇到此问题：**

> 请联系您的组织管理员（通常是 IT 部门或钉钉管理员），在钉钉开发平台的组织设置中启用「CLI 访问权限」。启用后无需重复操作。

### 第3层：业务 PAT Scope（Business Permission）

**解决问题**："这个具体操作是否被允许？"

这是**最常触发**的授权层。每个不同的业务能力可能对应不同的 PAT scope。

**机制说明：**
- 采用 host-owned PAT（主机所有权模型）
- 每个 scope 首次使用时触发一次授权提示
- 授权时可选择：一次性（once）/ 永久（permanent）/ 会话级（session）
- 推荐高频使用的 scope 选 permanent，避免反复打断

**AgentCode 的重要性：**

```bash
# 每次涉及 PAT 的命令都必须携带正确的 AgentCode
export DINGTALK_DWS_AGENTCODE="{AGENT_CODE}"   # ← 替换为你的标识
export DWS_CHANNEL="{AGENT_CODE}"               # ← 保持一致

# 错误示例（缺少 AgentCode 可能导致授权不生效）
dws pat chmod doc:read --grant-type permanent

# 正确示例
dws pat chmod doc:read --agentCode {AGENT_CODE} --grant-type permanent
```

## 授权状态诊断流程图

```
用户发起请求
    │
    ▼
执行 dws 命令
    │
    ├─ 成功 → 返回结果 ✅
    │
    ├─ not_authenticated / TOKEN_EXPIRED
    │   └→ 进入 Step A/B 重新登录
    │
    ├─ ORG_CLI_ACCESS_DENIED
    │   └→ 引导用户联系管理员开通组织权限
    │
    ├─ PAT_MEDIUM_RISK_NO_PERMISSION (+ requiredScopes)
    │   └→ 提取 requiredScopes
    │   └→ 向用户解释所需权限
    │   └→ 用户确认后执行 dws pat chmod
    │   └→ replay 原始命令
    │
    ├─ RECOVERY_EVENT_ID=<id>
    │   └→ 按 recovery-guide.md 执行恢复
    │
    └─ 其他错误
        └→ 加 --verbose 重试一次
        └→ 仍失败则报告错误详情
```

## 授权码处理（设备流）

当使用 `dws auth login --device` 时，dws 会输出类似以下内容：

```json
{
  "user_code": "ABCD-EFGH",
  "verify_url": "https://login.dingtalk.com/oauth2/device/verify.htm",
  "complete_url": "https://login.dingtalk.com/oauth2/device/verify.htm?user_code=ABCD-EFGH"
}
```

**Agent 应如何展示给用户：**

```text
🔐 需要授权登录钉钉

请在浏览器中打开以下链接完成授权：
https://login.dingtalk.com/oauth2/device/verify.htm?user_code=ABCD-EFGH

或者在授权页面输入授权码：ABCD-EFGH

等待您完成授权...
```

## 安全注意事项

1. **不要缓存或存储 access_token / refresh_token** — 这些由 dws 和系统 Keychain 管理
2. **不要把 AgentCode 当作秘密** — 它是标识符而非密码，但应保持一致
3. **授权码 (user_code) 有时效性** — 通常几分钟内过期，过期需重新获取
4. **permanent 授权的撤销** — 用户可在钉钉的授权管理页面撤回
5. **敏感操作必须二次确认** — 即使已获得 PAT 授权，删除/发送等操作仍需用户明确同意

## 与原版 WorkBuddy 授权的差异

| 项目 | WorkBuddy 原版 | 通用版 |
|---|---|---|
| AgentCode | 固定 `workbuddy` | 可配置 `{AGENT_CODE}` |
| DWS_CHANNEL | 固定 `workbuddy` | 可配置 `{AGENT_CODE}` |
| Python 路径 | 硬编码 macOS 路径 | 可配置 `{PYTHON_PATH}` |
| 浏览器自动打开 | 使用 `open` 命令 | 取决于平台桌面能力 |
| 授权提示模板 | 含 "WorkBuddy" 字样 | 使用 `{AGENT_NAME}` 占位符 |
