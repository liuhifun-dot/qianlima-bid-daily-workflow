# 钉钉 CLI 通用技能包 — 迁移部署指南

> **版本**: 2.0.0 | **基于**: dws (DingTalk Workspace CLI) >= 1.0.24
> **原版来源**: WorkBuddy 平台「钉钉套件」Skill v1.0.4，经平台无关化改造

---

## 快速开始（3 步部署）

### 前置条件

| 条件 | 要求 | 检查命令 |
|---|---|---|
| Node.js | >= 16.x | `node --version` |
| npm | 随 Node.js 安装 | `npm --version` |
| Python 3 | >= 3.8（推荐，辅助脚本需要）| `{PYTHON_PATH} --version` |
| Shell/Bash | 目标平台必须支持执行 shell 命令 | 由平台决定 |

### Step 1：安装 dws CLI

```bash
npm install -g dingtalk-workspace-cli

# 验证安装
dws version --format json
```

### Step 2：变量替换

将整个 skill 包复制到目标平台的 skill 目录后，执行全局替换：

```bash
# ===== 必须替换的变量 =====
{AGENT_CODE}   → 你的 Agent 标识符（建议小写英文+数字）
{AGENT_NAME}   → 你的 Agent 显示名称（用于向用户展示）
{PYTHON_PATH}  → Python 3 可执行文件完整路径

# ===== 示例：部署到腾讯 Qclaw =====
sed -i 's/{AGENT_CODE}/qclaw/g' SKILL.md references/*.md scripts/*.py
sed -i 's/{AGENT_NAME}/Qclaw/g' SKILL.md references/*.md
sed -i 's/{PYTHON_PATH}\/usr\/bin\/python3/python3/g' SKILL.md references/*.md scripts/*.py

# ===== 示例：部署到 Coze =====
sed -i 's/{AGENT_CODE}/coze-bot/g' SKILL.md references/*.md scripts/*.py
sed -i 's/{AGENT_NAME}/Coze Bot/g' SKILL.md references/*.md
# Coze 无本地 Python 时，跳过 Python 路径替换，或改为 Node.js 方案
```

### Step 3：首次授权登录

在目标平台上触发 Skill 后，按 SKILL.md 中的「Step 3 授权流程」完成：

1. 执行 `dws auth status --format json` 检查状态
2. 未登录则执行 `dws auth login` 或 `dws auth login --device`
3. 用户在浏览器/钉钉中完成 OAuth
4. 初始化基础权限 `doc:read`

---

## 目录结构说明

```
dingtalk-cli-universal-skill/
├── SKILL.md                          # ← 核心指令文档（AI Agent 主入口）
├── README.md                         # ← 本文件（迁移指南）
│
├── references/                       # 📚 参考文档
│   ├── universal-auth.md             #    通用授权方案（已去平台化）
│   ├── global-reference.md           #    全局参数、认证、环境变量、Raw API
│   ├── intent-guide.md               #    意图路由 + 易混淆场景对照
│   ├── field-rules.md                #    AI表格字段类型规则
│   ├── error-codes.md                #    各产品高频错误码 + 排查方法
│   ├── recovery-guide.md             #    Recovery 闭环流程
│   └── products/                     #    14个产品详细命令参考
│       ├── aitable.md                #       AI 表格 / 多维表
│       ├── attendance.md             #       考勤
│       ├── calendar.md               #       日历
│       ├── chat.md                   #       群聊与机器人
│       ├── contact.md                #       通讯录
│       ├── devdoc.md                 #       开放平台文档
│       ├── ding.md                   #       DING
│       ├── doc.md                    #       钉钉文档
│       ├── drive.md                  #       钉盘
│       ├── minutes.md                #       AI 听记
│       ├── oa.md                     #       OA 审批
│       ├── report.md                 #       日志
│       ├── mail.md                   #       邮箱
│       ├── todo.md                   #       待办
│       └── workbench.md              #       工作台
│
└── scripts/                          # 🔧 辅助脚本（Python 3）
    ├── dws_universal_setup.py        #    环境安装与检测脚本
    ├── bulk_add_fields.py            #    AI表格批量添加字段
    ├── import_records.py             #    AI表格批量导入记录
    ├── todo_batch_create.py          #    批量创建待办
    ├── todo_daily_summary.py         #    待办日汇总
    ├── todo_overdue_check.py         #    待办逾期检查
    ├── calendar_schedule_meeting.py  #    日程会议安排
    ├── calendar_today_agenda.py      #    今日日程
    ├── calendar_free_slot_finder.py  #    闲忙时段查找
    ├── contact_dept_members.py       #    部门成员查询
    ├── attendance_my_record.py       #      我的考勤记录
    ├── attendance_team_shift.py      #      团队排班查询
    ├── report_inbox_today.py         #    今日日志收件箱
    ├── upload_attachment.py          #    附件上传工具
    └── ...
```

## 平台适配矩阵

| 目标平台 | Shell 支持 | Node.js | Python 3 | 文件系统 | 适配难度 | 备注 |
|---|---|---|---|---|---|---|
| **WorkBuddy** | ✅ Bash | ✅ | ✅ | ✅ | ⭐ 原生 | 原版运行平台 |
| **腾讯 Qclaw** | ✅ Bash | ✅ | ✅ | ✅ | ⭐⭐ 低 | 需变量替换 + 路径调整 |
| **Coze (扣子)** | ✅ Code Interpreter | ✅ 插件 | ✅ 插件 | ⚠️ 有限 | ⭐⭐⭐ 中 | 文件系统有限，上传下载需适配 |
| **Dify** | ✅ Code Node | ✅ Docker | ✅ Docker | ✅ | ⭐⭐ 中 | 需配置 Tool 环境变量 |
| **GPT-4o GPTs** | ❌ 不支持 | N/A | ⚠️ Advanced Data Analysis | ❌ | ❌ 不可用 | 无 Shell 执行能力 |
| **Claude Projects** | ⚠️ MCP Server | 通过 MCP | 通过 MCP | ✅ | ⭐⭐⭐⭐ 高 | 需搭建 MCP Server 包装 dws |
| **自定义 Bot** | 取决于实现 | 取决于实现 | 取决于实现 | 取决于实现 | varies | 参考本文档适配 |

> **关键判断标准**: 目标平台是否支持 **Shell/Bash 命令执行**。不支持则无法使用此 Skill。

## 核心差异：原版 vs 通用版

### 已移除的平台耦合

| 项目 | 处理方式 |
|---|---|
| WorkBuddy 特有路径 (`~/.workbuddy/...`) | → 移除，改为相对路径或占位符 |
| macOS Python 路径硬编码 | → 替换为 `{PYTHON_PATH}` 占位符 |
| `DWS_CHANNEL="workbuddy"` 硬编码 | → 替换为 `{AGENT_CODE}` 占位符 |
| WorkBuddy Sandbox 安全策略引用 | → 改为通用的安全最佳实践 |
| WorkBuddy Tool 调用约定 | → 改为通用 Shell 调用模式 |

### 需要使用者自行配置的项目

```bash
# 1. AgentCode（每个平台不同）
export DINGTALK_DWS_AGENTCODE="{AGENT_CODE}"
export DWS_CHANNEL="{AGENT_CODE}"

# 2. Python 路径（如果使用辅助脚本）
# 在 SKILL.md 的 Step 2.5 中文安全部分和所有 .py 脚本的 shebang 行

# 3. NODE_OPTIONS 环境问题（常见坑）
# 如果平台默认设置 NODE_OPTIONS="--use-system-ca"，需要在每次 dws 调用前清除：
NODE_OPTIONS="" dws <command> [args]

# 4. 钉盘根目录（可选）
# 如果需要固定的钉盘文件夹作为工作根目录：
# 先用 dws drive mkdir 创建文件夹，记住返回的 fileId，后续操作加 --parent-id
```

## 授权流程详解（跨平台通用）

### 为什么有三次授权？

```
第1次: OAuth 登录     → "你是谁？"
       ↓ 浏览器/钉钉扫码确认身份
第2次: 组织CLI访问权限  → "你的公司允许用 CLI 吗？"
       ↓ 管理员在钉钉开放平台开启
第3次: 业务PAT scope    → "这个具体操作允许吗？"（如发消息、读文档、传文件）
       ↓ 每个新能力首次使用时触发，用户在钉钉内确认
```

### PAT Scope 合并策略（减少授权次数）

当同一工作流连续需要多个 scope 时，可以一次性申请：

```bash
# 示例：钉盘上传需要两个 scope
dws pat chmod drive:upload-info drive:commit \
  --agentCode {AGENT_CODE} \
  --grant-type once \
  --format json

# 示例：AI表格完整CRUD
dws pat chmod aitable.base:create aitable.table:create aitable.field:create aitable.record:create \
  --agentCode {AGENT_CODE} \
  --grant-type permanent \
  --format json
```

## 常见问题

### Q1: `dws` 命令找不到？

确保 npm 全局包路径在系统 PATH 中：

```bash
# 查看 npm 全局包位置
npm list -g --depth=0

# 将 npm 全局 bin 目录加入 PATH
export PATH="$(npm prefix -g)/bin:$PATH"
```

### Q2: `NODE_OPTIONS` 冲突导致报错？

部分平台（如 WorkBuddy）会预设 `NODE_OPTIONS="--use-system-ca"`，这会导致 dws 报错。解决：

```bash
# 方法1：每次调用时清除（推荐）
NODE_OPTIONS="" dws <command>

# 方法2：永久取消
unset NODE_OPTIONS
echo 'unset NODE_OPTIONS' >> ~/.bashrc
```

### Q3: 中文参数乱码？

参考 SKILL.md 的 Step 2.5，使用 Python subprocess 包装调用。

### Q4: 授权后还是报权限错误？

1. 检查三步授权是否全部完成（OAuth → 组织CLI → 业务PAT）
2. 查看错误输出中的 `requiredScopes` 字段
3. 用 `dws pat chmod <scope> --agentCode {AGENT_CODE}` 补充授权

### Q5: 如何在不同平台间迁移 dws 登录态？

dws 的 token 存储在本地 Keychain/凭据管理器中，**不能直接复制**。每个新环境都需要重新执行 `dws auth login`。

### Q6: 能否在没有桌面的服务器上使用？

可以，但只能用设备流授权（`dws auth login --device`），因为浏览器跳转方式需要有桌面环境。

## 版本历史

| 版本 | 日期 | 变更说明 |
|---|---|---|
| 2.0.0 | 2026-05-14 | 从 WorkBuddy v1.0.4 提取通用版本，移除平台耦合，增加迁移指南 |
| 1.0.4 | 2026-05-14 | 原版 WorkBuddy 最终版，含完整14产品覆盖 |

## 许可证

本 Skill 包基于原 WorkBuddy「钉钉套件」改造，遵循原许可协议。
核心依赖：[dingtalk-workspace-cli](https://www.npmjs.com/package/dingtalk-workspace-cli)（钉钉官方，遵循其许可）。
